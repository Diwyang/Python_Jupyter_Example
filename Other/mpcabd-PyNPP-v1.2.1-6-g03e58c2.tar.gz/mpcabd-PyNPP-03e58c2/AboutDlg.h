#ifndef _ABOUTDLG_H
#define _ABOUTDLG_H

#include "PluginInterface.h"

BOOL CALLBACK AboutDlg_dlgProcOptions(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif