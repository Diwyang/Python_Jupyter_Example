#ifndef _OPTIONSDLG_H
#define _OPTIONSDLG_H

#include "PluginInterface.h"

BOOL CALLBACK dlgProcOptions(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif